import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Stack;
public class IC {
	
	public static void read() throws IOException{	
		RandomAccessFile file = new RandomAccessFile("unalloc.img","r" );
		byte[] h = new byte[1]; // header/footer 	
		long OffsetH = 0;
		long OffsetF = 0;
		int CurrentOffset = (int)file.getFilePointer();
		int i = 0; //header counter
		int j = 0; //footer counter
		Stack<Long> offsets = new Stack<Long>();
		
	while(file.read()!= -1){ 
		
		file.seek(file.getFilePointer());
		//CurrentOffset = (int)file.getFilePointer();
		file.read(h,0,1);
		
		if((h[0]&0xFF) == 0xFF){
			file.read(h,0,1);
			
			//First Header Check
			if((h[0]&0xFF) == 0xD8){
				file.read(h,0,1);
				
				if((h[0]&0xFF) == 0xFF){
					
					i++;
					
					OffsetH = file.getFilePointer()-3;
					offsets.add(OffsetH);
					System.out.println("header found"+ i);
					System.out.println(Long.toHexString(OffsetH));
					System.out.println();
				file.read(h,0,1);
				}
			}
			//Footer check
			 if((h[0]&0xFF) == 0xD9 ){
				
				j++;
				OffsetF = file.getFilePointer()-2;
				 file.read(h,0,1);
			if(offsets.size() > 0){
					FileOutputStream output = new FileOutputStream(i + ".jpeg");
					Long headerOffset = offsets.peek();
					offsets.pop();
				
					byte[] b = new byte[(int) ((OffsetF+2)-headerOffset)];
					file.seek(headerOffset);
					file.read(b,0,b.length);
					output.write(b);
				
				}
			
				//System.out.println("footer found: "+ j);
				//System.out.println(Long.toHexString(OffsetF));
				//System.out.println();
				//file.read(h,0,1);
				
			}
	/*	 else{
			 if(thing == true){
			 System.out.println("Entered else");
			 }
				file.seek(file.getFilePointer()+3);
			} */
	
		}//First if end-bracket
		
		file.seek((file.getFilePointer()-1));
		
	} //1st While loop end-bracket
	
	//file.close();
}	
	public static void main(String [] args) throws IOException{
		read();
	}
}